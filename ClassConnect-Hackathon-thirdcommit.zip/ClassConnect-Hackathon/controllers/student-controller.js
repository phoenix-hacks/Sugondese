const Student = require("../models/student-model"); 
const College = require("../models/college-model")
const bcrypt = require("bcrypt");


const generateRandomId = () => {
    return `S${Math.floor(1000+Math.random()*9000)}`;
};

const SignUp = async (req, res) => {
    try {
        const { studentName ,studentPass, collegeId } = req.body;

        const college = await College.findOne({collegeId});
        if (!college) {
            return res.status(404).json({ message: "College not found!" });
        }

        let studentId;
        let isUnique = false;

        while (!isUnique) {
            studentId =generateRandomId();
            const existingStudent = await Student.findOne({ studentId });
            if (!existingStudent) {
                isUnique = true; 
            }
        }

        const hashedPassword = await bcrypt.hash(studentPass, 10);

        const newStudent = new Student({
            studentName,
            studentId,
            studentPass: hashedPassword,
            collegeId,
            collegeName:college
        });

        await newStudent.save();

        res.status(201).json({ 
            message: "Student registered successfully!", 
            studentId 
        });
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

const SignIn = async (req, res) => {
    try {
        const {studentId, studentPass, collegeId} = req.body;

        const student = await Student.findOne({studentId});
        const college = await College.findOne({collegeId});
        if (!college) {
            return res.status(404).json({ message: "College not found!" });
        }

        if (!student) {
            return res.status(404).json({ message: "Student not found!" });
        }

        const isPasswordCorrect = await bcrypt.compare(studentPass, student.studentPass);
        if (!isPasswordCorrect) {
            return res.status(400).json({ message: "Invalid credentials!" });
        }

        res.status(200).json({ 
            message: "Sign-in successful!",
            student: {
                studentId: student.studentId,
                studentName: student.studentName,
                collegeId: student.collegeId,
                collegeName: college.collegeName
            }
        });
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

module.exports = { SignUp, SignIn };