const Teacher = require("../models/teacher-model");
const College = require("../models/college-model")
const bcrypt = require("bcrypt");


const generateRandomId = () => {
    return `T${Math.floor(1000 + Math.random() * 9000)}`; 
};

const SignUp = async (req, res) => {
    try {
        const teacherId = generateRandomId();
        const { teacherName, subject, collegeId, password } = req.body;

        const college = await College.findOne({collegeId});
        if (!college) {
            return res.status(404).json({ message: "College not found!" });
        }
        console.log(college)
        const existingTeacher = await Teacher.findOne({ teacherId });

        if (existingTeacher) {
            return res.status(400).json({ message: "Teacher already exists!" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newTeacher = new Teacher({
            teacherId,
            teacherName,
            subject,
            collegeId,
            collegeName:college.collegeName,
            password: hashedPassword 
        });
        await newTeacher.save();
        res.status(201).json({ message: "Teacher registered successfully!", newTeacher });
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

const SignIn = async (req, res) => {
    try {
        const { collegeId,teacherId, password } = req.body;
        
        const college = await College.findOne({collegeId});
        if (!college) {
            return res.status(404).json({ message: "College not found!" });
        }
        const teacher = await Teacher.findOne({ teacherId });
        if (!teacher) {
            return res.status(404).json({ message: "Teacher not found!" });
        }

        const isPasswordCorrect = await bcrypt.compare(password, teacher.password);
        if (!isPasswordCorrect) {
            return res.status(400).json({ message: "Invalid credentials!" });
        }
        res.status(200).json({ message: "Teacher login successfully!" ,
            teacher: {
                teacherId: teacher.teacherId,
                teacherName: teacher.teacherName,
                collegeId: teacher.collegeId,
                collegeName: college.collegeName
            }
        });
        
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

module.exports = { SignUp, SignIn };
