const Notes = require("../models/notes-model");
const Teacher = require("../models/teacher-model")

const generateRandomId = () => {
    return `Note${Math.floor(1000+Math.random()*9000)}`;
};

const createNote = async (req, res) => {
    try {
        const {
            title,
            teacherId,
            branch,
            semester,
            subject,
            module,
            content,
            rating,
        }= req.body;
        let noteId= generateRandomId()
        const college = await Teacher.findOne({teacherId});
        const collegeId=college.collegeId
        const newNote= new Notes({
            noteId,
            title,
            collegeId,
            teacherId,
            branch,
            semester,
            subject,
            module,
            content,
            rating,
        })
        await newNote.save()
        res.status(201).json(newNote);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getAllNotes = async (req, res) => {
    try {
        const notes = await Notes.find().populate("teacherId", "teacherName");
        notes.sort((a,b)=>b.rating - a.rating)
        res.status(200).json(notes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const upVoteNotes = async (req, res) => {
    try {
        const { noteId } = req.body;

        const updatedNote = await Notes.findOneAndUpdate(
            { noteId },
            { $inc: { rating: 1 } },
            { new: true } 
        );

        if (!updatedNote) {
            return res.status(404).json({ error: "Note not found" });
        }

        res.status(200).json(updatedNote);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


module.exports = {createNote, getAllNotes, upVoteNotes}