const DoubtSession = require("../models/doubt-model");
const Teacher = require("../models/teacher-model")

const generateRandomId = () => {
    return `Topic${Math.floor(1000+Math.random()*9000)}`;
};

const createDoubtSession = async (req, res) => {
    try {
        const { title, teacherId, description, sessionDate, recordedSession } = req.body;
        let topicId = generateRandomId()
        const college = await Teacher.findOne({ teacherId });
        const collegeId = college.collegeId
        const newSession = new DoubtSession({
            topicId,
            title,
            collegeId,
            teacherId,
            description,
            sessionDate,
            recordedSession,
            studentsRegistered: []
        })
        
        
        await newSession.save();

        res.status(201).json({ message: "Doubt session created successfully!", session: newSession });
    } catch (error) {
        res.status(500).json({ message: "Error creating session", error: error.message });
    }
};

const registerStudent = async (req, res) => {
    try {
        const { topicId, studentId } = req.body;

        const session = await DoubtSession.findOne({ topicId });
        if (!session) {
            return res.status(404).json({ message: "Doubt session not found!" });
        }

        if (session.studentsRegistered.includes(studentId)) {
            return res.status(400).json({ message: "Student already registered for this session!" });
        }

        session.studentsRegistered.push(studentId);
        await session.save();

        res.status(200).json({ message: "Student registered successfully!", session, studentsreg:session.studentsRegistered.length });
    } catch (error) {
        res.status(500).json({ message: "Error registering student", error: error.message });
    }
};

const viewSessions = async (req, res) => {
    try {
        const sessions = await DoubtSession.find()
            .populate("teacherId", "teacherName subject")
            .populate("studentsRegistered", "studentName studentId");
        sessions.sort((a,b)=>{b.studentsRegistered.length - a.studentsRegistered.length})
        res.status(200).json(sessions);
    } catch (error) {
        res.status(500).json({ message: "Error fetching sessions", error: error.message });
    }
};


module.exports = {createDoubtSession, registerStudent, viewSessions}