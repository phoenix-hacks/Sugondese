const express = require("express");
const router = express.Router();
const controller = require("../controllers/notes-controller")

router.post("/postnotes", controller.createNote)
router.get("/allnotes", controller.getAllNotes)
router.put("/upvote", controller.upVoteNotes)

module.exports = router;