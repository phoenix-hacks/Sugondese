const express = require("express");
const router = express.Router();
const controller = require("../controllers/student-controller")

router.post("/signup",controller.SignUp)
router.post("/signin",controller.SignIn)

module.exports = router;        