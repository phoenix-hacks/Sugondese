const mongoose = require("mongoose");

const StudentSchema = mongoose.Schema(
    {
        studentName: {
            type: String,
            required: true
        },
        studentId: {
            type: String,
            required: true,
            unique: true
        },
        studentPass: {
            type: String,
            required: true
        },
        collegeId: { 
            type: String,
            required: true
        },
        collegeName: {
            type: String,
            required: true
        }
    }
)

const studentController = mongoose.model("Hstudent", StudentSchema);

module.exports = studentController;