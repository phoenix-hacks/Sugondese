const mongoose = require("mongoose");

const StudentSchema = mongoose.Schema(
    {
        collegeId: {
            type: String,
            required: true,
            unique: true
        },
        collegeName: {
            type: String,
            required: true
        }
    }
)

const collegeController = mongoose.model("Hcollege", StudentSchema);

module.exports = collegeController;