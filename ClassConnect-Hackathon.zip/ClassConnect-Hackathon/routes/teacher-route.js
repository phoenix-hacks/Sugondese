const express = require("express");
const router = express.Router();
const controller = require("../controllers/teacher-controller")

router.get("/signup",controller.SignUp)
router.get("/signin",controller.SignIn)

module.exports = router;    