const express = require("express");
const router = express.Router();
const controller = require("../controllers/college-controller")

router.post("/create",controller.createCollege)

module.exports = router;    