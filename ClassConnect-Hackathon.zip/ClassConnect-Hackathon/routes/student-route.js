const express = require("express");
const router = express.Router();
const controller = require("../controllers/student-controller")

router.get("/signup",controller.SignUp)
router.get("/signin",controller.SignIn)

module.exports = router;    