const College = require("../models/college-model"); 
const generateRandomId = () => {
    return `C${Math.floor(1000 + Math.random() * 9000)}`; 
};

const createCollege = async (req, res) => {

    try {
        const collegeId = generateRandomId();
        const {collegeName} = req.body;
        const existingCollege = await College.findOne({ collegeId });
        if (existingCollege) {
            return res.status(400).json({ message: "College ID already exists!"});
        }

        const newCollege = new College({ collegeId, collegeName });
        await newCollege.save();

        res.status(201).json({ message: "College created successfully!", college: newCollege });
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};
const getCollegeById = async (req, res) => {
    try {
        const { collegeId } = req.params;
        const college = await College.findOne({ collegeId });
        if (!college) {
            return res.status(404).json({ message: "College not found!" });
        }
        res.status(200).json({ college });
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

const listColleges = async (req, res) => {
    try {
        const colleges = await College.find();
        res.status(200).json({ colleges });
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

const deleteCollege = async (req, res) => {
    try {
        const { collegeId } = req.params;

        const deletedCollege = await College.findOneAndDelete({ collegeId });
        if (!deletedCollege) {
            return res.status(404).json({ message: "College not found!" });
        }

        res.status(200).json({ message: "College deleted successfully!", college: deletedCollege });
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

module.exports = { createCollege, getCollegeById, listColleges, deleteCollege };