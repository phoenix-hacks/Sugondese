const Teacher = require("../models/teacher-model");
const bcrypt = require("bcrypt");


const generateRandomId = () => {
    return `T${Math.floor(1000 + Math.random() * 9000)}`; 
};

const SignUp = async (req, res) => {
    try {
        const teacherId = generateRandomId();
        const { teacherName, subject, collegeId, password } = req.body;

        const existingTeacher = await Teacher.findOne({ teacherId });
        if (existingTeacher) {
            return res.status(400).json({ message: "Teacher already exists!" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newTeacher = new Teacher({
            teacherId,
            teacherName,
            subject,
            collegeId,
            password: hashedPassword 
        });

        await newTeacher.save();
        res.status(201).json({ message: "Teacher registered successfully!" });
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

const SignIn = async (req, res) => {
    try {
        const { teacherId, password } = req.body;

        const teacher = await Teacher.findOne({ teacherId });
        if (!teacher) {
            return res.status(404).json({ message: "Teacher not found!" });
        }

        const isPasswordCorrect = await bcrypt.compare(password, teacher.password);
        if (!isPasswordCorrect) {
            return res.status(400).json({ message: "Invalid credentials!" });
        }
        
    } catch (error) {
        res.status(500).json({ message: "Something went wrong", error: error.message });
    }
};

module.exports = { SignUp, SignIn };
