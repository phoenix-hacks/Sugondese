const express = require("express")
const app = express()

const routecollege = require("./routes/college-route")

const routestudent = require("./routes/college-route")

const routeteacher = require("./routes/college-route")

const mongoose = require("mongoose")
app.use(express.json())


app.use("/api", routecollege);
app.use("/api", routestudent);
app.use("/api", routeteacher);


mongoose.connect("mongodb+srv://manohar2004gr:5DFpcNwqPVvyLaww@testapi.unppitm.mongodb.net/?retryWrites=true&w=majority&appName=TestApi")
    .then(() => {
        console.log("Successfully connected to DB!");
        app.listen(3000, () => {
            console.log(`Server is listening on port 3000`);
        });
    })
    .catch((err) => {
        console.log("Database connection error: ", err.message);
    });
