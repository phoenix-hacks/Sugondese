const mongoose = require("mongoose");

const TeacherSchema = mongoose.Schema({
    teacherId: {
        type: String,
        required: true,
        unique: true
    },
    teacherName: {
        type: String,
        required: true
    },
    subject: {
        type: String,
        required: true
    },
    collegeId: { 
        type: mongoose.Schema.Types.ObjectId,
        ref: "Hcollege",
        required: true
    },
    password: { 
        type: String,
        required: true
    }
});

module.exports = mongoose.model("Hteacher", TeacherSchema);
