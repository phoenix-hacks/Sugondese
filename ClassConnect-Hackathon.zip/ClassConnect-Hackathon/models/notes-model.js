const mongoose = require("mongoose");

const NotesSchema = mongoose.Schema({
    noteId: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true 
    },
    author: { 
        type: mongoose.Schema.Types.ObjectId,
        ref: "Hteacher", 
        required: true
    },
    section: {
        type: String,
        required: true 
    },
    content: {
        type: String,
        required: true 
    },
    rating: {
        type: Number,
        default: 0,
        min: 0,
        max: 5
    },
    uploadedAt: {
        type: Date,
        default: Date.now 
    }
}, {
    timestamps: true 
});

module.exports = mongoose.model("Hnotes", NotesSchema);
