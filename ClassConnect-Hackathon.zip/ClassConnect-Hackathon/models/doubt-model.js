const mongoose = require("mongoose");

const DoubtSessionSchema = mongoose.Schema({
    topicId: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true 
    },
    teacherId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Hteacher",
        required: true
    },
    description: {
        type: String,
        required: true
    },
    sessionDate: {
        type: Date,
        required: true 
    },
    studentsRegistered: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Hstudent"
    }],
    recordedSession: {
        type: String,
        required: true
    }
}, {
    timestamps: true 
});

module.exports = mongoose.model("Hdoubt", DoubtSessionSchema);
