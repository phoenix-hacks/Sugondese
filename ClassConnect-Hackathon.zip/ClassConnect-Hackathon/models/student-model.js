const mongoose = require("mongoose");

const StudentSchema = mongoose.Schema(
    {
        studentId: {
            type: String,
            required: true,
            unique: true
        },
        studentPass: {
            type: String,
            required: true
        },
        collegeId: { 
            type: mongoose.Schema.Types.ObjectId,
            ref: "Hcollege",
            required: true
        }
    }
)

const studentController = mongoose.model("Hstudent", StudentSchema);

module.exports = studentController;