const mongoose = require("mongoose");

const NotesSchema = mongoose.Schema(
    {
        noteId: {
            type: String,
            required: true,
            unique: true,
        },
        title: {
            type: String,
            required: true,
        },
        collegeId: {
            type: String,
            required: true,
        },
        teacherId: {
            type: String,
            required: true,
        },
        branch: {
            type: String,
            required: true, 
        },
        semester: {
            type: Number,
            required: true,
            min: 1,
            max: 8,
        },
        subject: {
            type: String,
            required: true, 
        },
        module: {
            type: Number,
            required: true,
            min: 1,
            max: 5,
        },
        
        content: {
            type: String,
            required: true,
        },
        rating: {
            type: Number,
            default: 0,
        },
        uploadedAt: {
            type: Date,
            default: Date.now,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model("Hnotes", NotesSchema);