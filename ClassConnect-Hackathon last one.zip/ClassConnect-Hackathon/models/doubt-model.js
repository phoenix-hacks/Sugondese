const mongoose = require("mongoose");

const DoubtSessionSchema = mongoose.Schema({
    topicId: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true 
    },
    teacherId: {
        type: String,
        required: true
    },
    collegeId: { 
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    sessionDate: {
        type: Date,
        required: true,
       
    },
    status: {
        type: String,
        enum: ["Scheduled", "Completed", "Cancelled"],
        default: "Scheduled",
    },
    studentsRegistered: [{
        type: String,
        required: true
    }],
    recordedSession: {
        type: String,
        default: null,
    },
}, {
    timestamps: true 
});

module.exports = mongoose.model("Hdoubt", DoubtSessionSchema);
