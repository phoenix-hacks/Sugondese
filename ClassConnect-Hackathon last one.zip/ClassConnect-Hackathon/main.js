const express = require("express")
const app = express()

const routecollege = require("./routes/college-route")

const routestudent = require("./routes/student-route")

const routeteacher = require("./routes/teacher-route")

const routedoubt = require("./routes/doubt-route")

const routenote = require("./routes/notes-route")

const mongoose = require("mongoose")
app.use(express.json())
const cors = require("cors");
app.use(cors());
app.use(express.urlencoded({extended:false}))

app.use("/college", routecollege);
app.use("/student", routestudent);
app.use("/teacher", routeteacher);
app.use("/doubt", routedoubt);
app.use("/notes", routenote);


mongoose.connect("mongodb+srv://manohar2004gr:5DFpcNwqPVvyLaww@testapi.unppitm.mongodb.net/?retryWrites=true&w=majority&appName=TestApi")
    .then(() => {
        console.log("Successfully connected to DB!");
        app.listen(3000, () => {
            console.log(`Server is listening on port 3000`);
        });
    })
    .catch((err) => {
        console.log("Database connection error: ", err.message);
    });
