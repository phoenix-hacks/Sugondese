const express = require("express");
const router = express.Router();
const controller = require("../controllers/doubt-controller")

router.post("/create",controller.createDoubtSession)
router.post("/register",controller.registerStudent)
router.get("/view",controller.viewSessions)

module.exports = router;    