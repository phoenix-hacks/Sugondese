import React, { useState } from "react";
import './Form.css';
const Login = ({ role, onSuccess }) => {
    const [formData, setFormData] = useState({
        userId: "",
        password: ""
    });
    const [message, setMessage] = useState("");

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async(e) => {
        e.preventDefault();
        try {
            const apiUrl =
                role === "Teacher"
                    ? "http://localhost:3000/teacher/signin"
                    : "http://localhost:3000/student/signin";

            const response = await fetch(apiUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(formData),
            });

            const result = await response.json();

            if (response.ok) {
                setMessage(result.message || "Login successful!");
                onSuccess(result.userData);
            } else {
                setMessage(result.message || "Login failed!");
            }
        } catch (error) {
            setMessage("Something went wrong!");
            console.error("Login Error:", error);
        }
    };

    return (
        <div className="login-container">
            <h2>{role} Login</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>User ID:</label>
                    <input
                        type="text"
                        name="userId"
                        value={formData.userId}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit">Login</button>
            </form>
            {message && <p>{message}</p>}
        </div>
    );
};

export default Login;