import React, { useState } from "react";
import './Form.css';
const Signup = ({ role, onSuccess }) => {
    const [formData, setFormData] = useState({
        name: "",
        subject: "",
        password: "",
        collegeId: ""
    });

    const [message, setMessage] = useState("");

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const apiUrl =
                role === "Teacher"
                    ? "http://localhost:3000/teacher/signup"
                    : "http://localhost:3000/student/signup";

            const payload = {
                ...formData,
                [role === "Teacher" ? "teacherName" : "studentName"]: formData.name,
            };
            delete payload.name;

            const response = await fetch(apiUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            });

            const result = await response.json();

            if (response.ok) {
                setMessage(result.message || "Signup successful!");
                onSuccess(result.userData);
            } else {
                setMessage(result.message || "Signup failed!");
            }
        } catch (error) {
            setMessage("Something went wrong!");
            console.error("Signup Error:", error);
        }
    };

    return (
        <div className="signup-container">
            <h2>{role} Signup</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>{role === "Teacher" ? "Teacher Name:" : "Student Name:"}</label>
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                </div>

                {role === "Teacher" && (
                    <div>
                        <label>Subject:</label>
                        <input
                            type="text"
                            name="subject"
                            value={formData.subject}
                            onChange={handleChange}
                            required
                        />
                    </div>
                )}

                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>College ID:</label>
                    <input
                        type="text"
                        name="collegeId"
                        value={formData.collegeId}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit">Signup</button>
            </form>
            {message && <p>{message}</p>}
        </div>
    );
};

export default Signup;