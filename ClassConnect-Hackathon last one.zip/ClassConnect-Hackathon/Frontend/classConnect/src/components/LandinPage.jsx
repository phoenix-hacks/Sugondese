import React from "react";
import { useNavigate } from "react-router-dom";
import "./LandingPage.css";

const LandingPage = () => {
  const navigate = useNavigate();
  const userData = JSON.parse(localStorage.getItem('userData'));
  const userRole = localStorage.getItem('userRole');

  const handleLogout = () => {
    localStorage.removeItem('userData');
    localStorage.removeItem('userRole');
    navigate('/auth');
  };

  return (
    <div className="landing-container">
      <header className="landing-header">
        <h1>Welcome, {userData?.name || 'User'}!</h1>
        <button onClick={handleLogout} className="logout-btn">Logout</button>
      </header>

      <main className="landing-main">
        <section className="profile-section">
          <h2>Your Profile</h2>
          <div className="profile-details">
            <p><strong>Role:</strong> {userRole}</p>
            <p><strong>College ID:</strong> {userData?.collegeId}</p>
            {userRole === 'Teacher' && (
              <p><strong>Subject:</strong> {userData?.subject}</p>
            )}
          </div>
        </section>

        <section className="actions-section">
          <h2>Quick Actions</h2>
          <div className="action-buttons">
            {userRole === 'Teacher' ? (
              <>
                <button className="action-btn">Create New Assignment</button>
                <button className="action-btn">View Student Submissions</button>
                <button className="action-btn">Manage Classes</button>
              </>
            ) : (
              <>
                <button className="action-btn">View Assignments</button>
                <button className="action-btn">Check Grades</button>
                <button className="action-btn">View Course Material</button>
              </>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};

export default LandingPage;