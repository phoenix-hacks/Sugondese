import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Login from "./Login";
import Signup from "./Signup";
import './Auth.css';

const Auth = () => {
    const [role, setRole] = useState("Student");
    const [authType, setAuthType] = useState("Login");
    const navigate = useNavigate();

    const handleAuthSuccess = (userData) => {
        localStorage.setItem('userData', JSON.stringify(userData));
        localStorage.setItem('userRole', role);
        navigate('/dashboard');
    };

    return (
        <div className="auth-container">
            <h1>Welcome to the Portal</h1>
            <div>
                <button onClick={() => setRole("Student")}>Student</button>
                <button onClick={() => setRole("Teacher")}>Teacher</button>
            </div>
            <div>
                <button onClick={() => setAuthType("Login")}>Login</button>
                <button onClick={() => setAuthType("Signup")}>Signup</button>
            </div>
            <div className="form-container">
                {authType === "Login" ? (
                    <Login role={role} onSuccess={handleAuthSuccess} />
                ) : (
                    <Signup role={role} onSuccess={handleAuthSuccess} />
                )}
            </div>
        </div>
    );
};

export default Auth;