import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Auth from './components/Auth';
import LandingPage from './components/LandinPage';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/auth" element={<Auth />} />
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <LandingPage />
            </ProtectedRoute>
          } 
        />
        <Route path="/" element={<Navigate to="/auth" replace />} />
      </Routes>
    </Router>
  );
};

const ProtectedRoute = ({ children }) => {
  const userData = JSON.parse(localStorage.getItem('userData'));
  
  if (!userData) {
    return <Navigate to="/auth" replace />;
  }
  
  return children;
};

export default App;